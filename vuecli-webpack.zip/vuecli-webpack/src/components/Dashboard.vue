<template>
  <v-main>
    <v-img
      class="mx-auto mt-10"
      :src="require('@/assets/logofull.png')"
      max-width="300"
    />
    <!-- <h1 class="text-h3 font-weight-medium mb-5 white--text">Atma Korean BBQ</h1>
    <p class="subtitle-1 white--text">Fun Place to Grill</p> -->
  </v-main>
</template>
