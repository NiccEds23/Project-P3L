<!--@format-->

<template>
  <div class="dashboard">
    <v-navigation-drawer
      v-model="drawer"
      class="fullheight"
      width="250"
      color="#00695C"
      app
    >
      <v-list-item>
        <v-list-item-content>
          <v-list-item-title class="title" color="white">
            Atma Korean BBQ
          </v-list-item-title>
          <v-list-item-subtitle> D A E B A K ! </v-list-item-subtitle>

          <p class="font-weigth-medium white--text">
            <br />
            Selamat Datang,
          </p>
          <p class="font-weight-bold font-italic white--text">
            {{ name }} ( {{ nama_role }} )
          </p></v-list-item-content
        >
      </v-list-item>

      <v-divider></v-divider>

      <v-list dense nav>
        <v-list-item
          v-for="item in items"
          :key="item.title"
          link
          tag="router-link"
          :to="item.to"
        >
          <v-list-item-icon>
            <v-icon class="text-right">{{ item.icon }}</v-icon>
          </v-list-item-icon>
          <v-list-item-content>
            <v-list-item-title class="text-left">
              {{ item.title }}
            </v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list>
    </v-navigation-drawer>
    <v-app-bar app fixed height="60px">
      <v-app-bar-nav-icon @click.stop="drawer = !drawer"></v-app-bar-nav-icon>
      <VSpacer />
      <v-toolbar-items>
        <v-list-item>
          <v-list-item-subtitle
            class="font-weight-bold font-italic white--text text-decoration-underline"
          >
            <!-- <br /> -->
            Tanggal Hari ini :
            {{ todayDate }}
          </v-list-item-subtitle>
        </v-list-item>
        <v-tooltip bottom>
          <template v-slot:activator="{ on, attrs }">
            <v-btn @click="logout" text router v-bind="attrs" v-on="on"
              ><v-icon>mdi-power</v-icon></v-btn
            >
          </template>
          <span> Logut </span>
        </v-tooltip>
      </v-toolbar-items>
    </v-app-bar>
    <div class="fullheight pa-5">
      <router-view></router-view>
    </div>
  </div>
</template>
<script>
export default {
  name: "Dashboard",
  data() {
    return {
      drawer: true,
      role: "",
      nama_role: "",
      name: "",
      items: [],
      itemsOwner: [
        { title: "Dashboard", to: "/dashboard", icon: "mdi-view-dashboard" },
        { title: "Karyawan", to: "/karyawan", icon: "mdi-account-multiple" },
      ],
      itemsOM: [
        { title: "Dashboard", to: "/dashboard", icon: "mdi-view-dashboard" },
        { title: "Bahan", to: "/bahan", icon: "mdi-food-drumstick" },
        {
          title: "Customer",
          to: "/customer",
          icon: "mdi-account-box-multiple",
        },
        { title: "Karyawan", to: "/karyawan", icon: "mdi-account-multiple" },
        { title: "Meja", to: "/meja", icon: "mdi-table-furniture" },
        { title: "Menu", to: "/menu", icon: "mdi-silverware" },
        { title: "Pembayaran", to: "/pembayaran", icon: "mdi-cash-multiple" },
        { title: "Pesanan", to: "/pesanan", icon: "mdi-food" },
        { title: "Reservasi", to: "/reservasi", icon: "mdi-account-clock" },
        { title: "Stok Bahan", to: "/stokBahan", icon: "mdi-food-variant" },
      ],
      itemsWaiter: [
        {
          title: "Customer",
          to: "/customer",
          icon: "mdi-account-box-multiple",
        },
        { title: "Meja", to: "/meja", icon: "mdi-table-furniture" },
        { title: "Pesanan", to: "/pesanan", icon: "mdi-food" },
        { title: "Reservasi", to: "/reservasi", icon: "mdi-account-clock" },
      ],
      itemsCashier: [
        {
          title: "Customer",
          to: "/customer",
          icon: "mdi-account-box-multiple",
        },
        { title: "Meja", to: "/meja", icon: "mdi-table-furniture" },
        { title: "Pembayaran", to: "/pembayaran", icon: "mdi-cash-multiple" },
        { title: "Pesanan", to: "/pesanan", icon: "mdi-food" },
        { title: "Reservasi", to: "/reservasi", icon: "mdi-account-clock" },
      ],
      itemsChef: [
        { title: "Bahan", to: "/bahan", icon: "mdi-food-drumstick" },
        { title: "Pesanan", to: "/pesanan", icon: "mdi-food" },
        { title: "Stok Bahan", to: "/stokBahan", icon: "mdi-food-variant" },
      ],
      todayDate: new Date().toISOString().substr(0, 10),
    };
  },
  methods: {
    logout() {
      localStorage.removeItem("token");

      this.$router.push({
        name: "login",
      });
    },
  },
  mounted() {
    this.name = localStorage.getItem("name");
    this.role = localStorage.getItem("role");
    if (this.role == 1) {
      this.items = this.itemsOwner;
      this.nama_role = "Owner";
    } else if (this.role == 2) {
      this.items = this.itemsOM;
      this.nama_role = "Ops Manager";
    } else if (this.role == 3) {
      this.items = this.itemsWaiter;
      this.nama_role = "Waiter";
    } else if (this.role == 4) {
      this.items = this.itemsCashier;
      this.nama_role = "Cashier";
    } else {
      this.items = this.itemsChef;
      this.nama_role = "Chef";
    }
  },
};
</script>

<style scoped>
.fullheight {
  min-height: 100vh !important;
}
.router {
  text-decoration: none;
  color: black;
}
</style>
