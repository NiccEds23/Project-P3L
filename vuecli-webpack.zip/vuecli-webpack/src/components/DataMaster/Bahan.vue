<template>
  <v-main class="list">
    <h3 class="text-h3 font-weight-medium mb-5 font-weight-bold white--text">
      Bahan
    </h3>

    <v-card>
      <v-card-title>
        <v-text-field
          v-model="search"
          append-icon="mdi-magnify"
          label="Search"
          single-line
          hide-details
        ></v-text-field>

        <v-spacer></v-spacer>
        <v-tooltip bottom>
          <template v-slot:activator="{ on, attrs }">
            <v-btn
              icon
              color="success"
              dark
              @click="dialog = true"
              v-bind="attrs"
              v-on="on"
            >
              <v-icon> mdi-plus </v-icon>
            </v-btn>
          </template>
          <span> Tambah Bahan </span>
        </v-tooltip>
        <v-tooltip bottom>
          <template v-slot:activator="{ on, attrs }">
            <v-btn
              icon
              color="blue"
              dark
              @click="dialogStokMasuk = true"
              v-bind="attrs"
              v-on="on"
            >
              <v-icon> mdi-basket-plus </v-icon>
            </v-btn>
          </template>
          <span> Tambah Stok Bahan </span>
        </v-tooltip>
        <v-tooltip bottom>
          <template v-slot:activator="{ on, attrs }">
            <v-btn
              icon
              color="red"
              dark
              @click="dialogBuangBahan = true"
              v-bind="attrs"
              v-on="on"
            >
              <v-icon> mdi-trash-can </v-icon>
            </v-btn>
          </template>
          <span> Buang Bahan </span>
        </v-tooltip>
      </v-card-title>
      <v-switch
        v-model="tampilKosong"
        :label="`Tampil Bahan Kosong`"
      ></v-switch>
      <!-- <v-data-table :headers="headers" :items="bahans" :search="search">
        <template v-slot:[`item.jumlah_bahan`]="{ item }">
          <v-chip :color="getColor(item.jumlah_bahan)" dark>
            {{ item.jumlah_bahan }}
          </v-chip>
        </template>
        <template v-slot:[`item.actions`]="{ item }">
          <v-btn icon color="blue" @click="editHandler(item)">
            <v-icon> mdi-pencil </v-icon>
          </v-btn>

          <v-btn icon color="red" @click="deleteHandler(item.id)">
            <v-icon> mdi-delete </v-icon>
          </v-btn>
        </template>
      </v-data-table> -->
      <v-container v-if="tampilKosong == false">
        <v-data-table :headers="headers" :items="bahans" :search="search">
          <template v-slot:[`item.jumlah_bahan`]="{ item }">
            <v-chip :color="getColor(item.jumlah_bahan)" dark>
              {{ item.jumlah_bahan }}
            </v-chip>
          </template>
          <template v-slot:[`item.actions`]="{ item }">
            <v-btn icon color="blue" @click="editHandler(item)">
              <v-icon> mdi-pencil </v-icon>
            </v-btn>

            <v-btn icon color="red" @click="deleteHandler(item.id)">
              <v-icon> mdi-delete </v-icon>
            </v-btn>
          </template>
        </v-data-table>
      </v-container>

      <v-container v-if="tampilKosong == true">
        <v-data-table :headers="headers" :items="bahanKosongs" :search="search">
          <template v-slot:[`item.jumlah_bahan`]="{ item }">
            <v-chip :color="getColor(item.jumlah_bahan)" dark>
              {{ item.jumlah_bahan }}
            </v-chip>
          </template>
          <template v-slot:[`item.actions`]="{ item }">
            <v-btn icon color="blue" @click="editHandler(item)">
              <v-icon> mdi-pencil </v-icon>
            </v-btn>

            <v-btn icon color="red" @click="deleteHandler(item.id)">
              <v-icon> mdi-delete </v-icon>
            </v-btn>
          </template>
        </v-data-table>
      </v-container>
    </v-card>

    <v-dialog v-model="dialog" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <span class="headline">{{ formTitle }} Bahan</span>
        </v-card-title>

        <v-card-text>
          <v-form v-model="valid" ref="form">
            <v-text-field
              v-model="form.nama_bahan"
              label="Nama Bahan"
              required
              :rules="bahanRules"
            ></v-text-field>

            <v-select
              v-model="form.unit_bahan"
              :items="['Gr', 'Ml']"
              label="Unit bahan"
              required
              :rules="unitRules"
            ></v-select>
          </v-form>
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn color="blue darken-1" text @click="cancel">
            Cancel
          </v-btn>

          <v-btn color="blue darken-1" text @click="setForm">
            Save
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogEdit" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <span class="headline">{{ formTitle }} Karyawan</span>
        </v-card-title>

        <v-card-text>
          <v-container>
            <v-text-field
              v-model="form.nama_bahan"
              label="Nama Bahan"
              required
            ></v-text-field>

            <v-select
              v-model="form.unit_bahan"
              :items="['Gr', 'Ml']"
              label="Unit bahan"
              required
            ></v-select>
          </v-container>
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn color="blue darken-1" text @click="cancel">
            Cancel
          </v-btn>

          <v-btn color="blue darken-1" text @click="update">
            Save
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogConfirm" persistent max-width="400px">
      <v-card>
        <v-card-title>
          <span class="headline">Warning!</span>
        </v-card-title>

        <v-card-text>
          Anda yakin ingin menghapus bahan ini?
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn color="blue darken-1" text @click="dialogConfirm = false">
            Cancel
          </v-btn>

          <v-btn color="blue darken-1" text @click="deleteData">
            Delete
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogStokMasuk" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <span class="headline">{{ formTitle }} Stok Bahan</span>
        </v-card-title>

        <v-card-text>
          <v-form v-model="valid" ref="form">
            <v-select
              v-model="form.id_bahan"
              :items="bahans"
              item-text="nama_bahan"
              item-value="id"
              label="Nama Bahan"
              :rules="bahanRules"
              required
            ></v-select>

            <v-text-field
              v-model="form.jumlah_masuk"
              label="Jumlah Bahan"
              :rules="jumlahRules"
              required
            ></v-text-field>

            <v-select
              v-model="form.unit_stok_bahan"
              :items="['Gr', 'Ml']"
              label="Unit bahan"
              :rules="unitRules"
              required
            ></v-select>

            <v-text-field
              v-model="form.harga_stok_bahan"
              label="Harga Bahan"
              prefix="Rp "
              :rules="hargaRules"
              required
            ></v-text-field>
          </v-form>
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn color="blue darken-1" text @click="cancel">
            Cancel
          </v-btn>

          <v-btn color="blue darken-1" text @click="setFormStok">
            Save
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogBuangBahan" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <span class="headline">Buang Bahan</span>
        </v-card-title>

        <v-card-text>
          <v-form v-model="valid" ref="form">
            <v-select
              v-model="form.id_bahan"
              :items="bahans"
              item-text="nama_bahan"
              item-value="id"
              label="Nama Bahan"
              :rules="bahanRules"
              required
            ></v-select>

            <v-text-field
              v-model="form.jumlah_terbuang"
              label="Jumlah Bahan Dibuang"
              :rules="jumlahRules"
              required
            ></v-text-field>
          </v-form>
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn color="blue darken-1" text @click="cancel">
            Cancel
          </v-btn>

          <v-btn color="blue darken-1" text @click="setFormBuang">
            Save
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-snackbar v-model="snackbar" :color="color" timeout="2000" bottom>
      {{ error_message }}
    </v-snackbar>
  </v-main>
</template>
<script>
export default {
  nama_bahan: "List",
  data() {
    return {
      inputType: "Tambah",
      load: false,
      snackbar: false,
      error_message: "",
      color: "",
      search: null,
      dialog: false,
      dialogEdit: false,
      dialogConfirm: false,
      dialogStokMasuk: false,
      dialogBuangBahan: false,
      headers: [
        {
          text: "Nama Bahan",
          align: "start",
          sortable: true,
          value: "nama_bahan",
        },
        { text: "Jumlah bahan", value: "jumlah_bahan" },
        { text: "Unit Bahan", value: "unit_bahan" },
        { text: "Actions", value: "actions" },
      ],
      bahan: new FormData(),
      stokBahanMasuk: new FormData(),
      historyStokBahan: new FormData(),
      bahans: [],
      bahanKosongs: [],
      form: {
        nama_bahan: "",
        unit_bahan: "",
        id_bahan: "",
        jumlah_masuk: "",
        unit_stok_bahan: "",
        harga_stok_bahan: "",
        jumlah_terbuang: "",
      },
      deleteId: "",
      editId: "",
      tampilKosong: false,
      date: new Date().toISOString().substr(0, 10),
      bahanRules: [(v) => !!v || "Nama Bahan tidak boleh kosong"],
      unitRules: [(v) => !!v || "Unit Bahan tidak boleh kosong"],
      jumlahRules: [(v) => !!v || "Jumlah Bahan tidak boleh kosng"],
      hargaRules: [(v) => !!v || "Harga Bahan tidak boleh kosng"],
    };
  },
  methods: {
    setForm() {
      if (this.inputType === "Tambah") {
        this.save();
      } else {
        this.update();
      }
    },
    setFormStok() {
      this.saveStok();
    },
    setFormBuang() {
      this.saveBuang();
    },
    //read data bahan
    readData() {
      var url = this.$api + "/bahan";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.bahans = response.data.data;
        });
    },
    //read data bahan kosong
    readDataKosong() {
      var url = this.$api + "/bahanKosong";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.bahanKosongs = response.data.data;
        });
    },
    //simpan data produk
    save() {
      if (this.$refs.form.validate()) {
        this.bahan.append("nama_bahan", this.form.nama_bahan);
        this.bahan.append("jumlah_bahan", "0");
        this.bahan.append("unit_bahan", this.form.unit_bahan);

        var url = this.$api + "/bahan/";
        this.load = true;
        this.$http
          .post(url, this.bahan, {
            headers: {
              Authorization: "Bearer " + localStorage.getItem("token"),
            },
          })
          .then((response) => {
            this.error_message = response.data.message;
            this.color = "green";
            this.snackbar = true;
            this.load = false;
            this.close();
            this.readData(); //mengambil data
            this.resetForm();
          })
          .catch((error) => {
            this.error_message = error.response.data.message;
            this.color = "red";
            this.snackbar = true;
            this.load = false;
          });
      }
    },
    saveStok() {
      if (this.$refs.form.validate()) {
        this.stokBahanMasuk.append("id_bahan", this.form.id_bahan);
        this.stokBahanMasuk.append("id_karyawan", localStorage.getItem("id"));
        this.stokBahanMasuk.append("jumlah_masuk", this.form.jumlah_masuk);
        this.stokBahanMasuk.append(
          "unit_stok_bahan",
          this.form.unit_stok_bahan
        );
        this.stokBahanMasuk.append(
          "harga_stok_bahan",
          this.form.harga_stok_bahan
        );
        this.stokBahanMasuk.append("tanggal_history", this.date);

        var url = this.$api + "/stokBahanMasuk/";
        this.load = true;
        this.$http
          .post(url, this.stokBahanMasuk, {
            headers: {
              Authorization: "Bearer " + localStorage.getItem("token"),
            },
          })
          .then((response) => {
            this.error_message = response.data.message;
            this.color = "green";
            this.snackbar = true;
            this.load = false;
            this.close();
            this.readData(); //mengambil data
            this.resetForm();
          })
          .catch((error) => {
            this.error_message = error.response.data.message;
            this.color = "red";
            this.snackbar = true;
            this.load = false;
          });
      }
    },
    //save buang bahan
    saveBuang() {
      if (this.$refs.form.validate()) {
        this.historyStokBahan.append("id_bahan", this.form.id_bahan);
        this.historyStokBahan.append("id_karyawan", localStorage.getItem("id"));
        this.historyStokBahan.append(
          "jumlah_terbuang",
          this.form.jumlah_terbuang
        );
        this.historyStokBahan.append(
          "tanggal_history",
          new Date().toISOString().substr(0, 10)
        );

        var url = this.$api + "/historyStokBahanBuang";
        this.load = true;
        this.$http
          .post(url, this.historyStokBahan, {
            headers: {
              Authorization: "Bearer " + localStorage.getItem("token"),
            },
          })
          .then((response) => {
            this.error_message = response.data.message;
            this.color = "green";
            this.snackbar = true;
            this.load = false;
            this.close();
            this.readData(); //mengambil data
            this.resetForm();
          })
          .catch((error) => {
            this.error_message = error.response.data.message;
            this.color = "red";
            this.snackbar = true;
            this.load = false;
          });
      }
    },
    //ubah data produk
    update() {
      let newData = {
        nama_bahan: this.form.nama_bahan,
        unit_bahan: this.form.unit_bahan,
      };
      var url = this.$api + "/bahan/" + this.editId;
      this.load = true;
      this.$http
        .put(url, newData, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          this.close();
          this.readData(); //mengambil data
          this.resetForm();
          this.inputType = "Tambah";
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    //hapus data produk
    deleteData() {
      //mengahapus data
      var url = this.$api + "/bahan/" + this.deleteId;
      //data dihapus berdasarkan id
      this.$http
        .delete(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          this.close();
          this.readData(); //mengambil data
          this.resetForm();
          this.inputType = "Tambah";
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    editHandler(item) {
      this.inputType = "Ubah";
      this.editId = item.id;
      this.form.nama_bahan = item.nama_bahan;
      this.form.unit_bahan = item.unit_bahan;
      this.dialogEdit = true;
    },
    deleteHandler(id) {
      this.deleteId = id;
      this.dialogConfirm = true;
    },
    close() {
      this.dialog = false;
      this.dialogEdit = false;
      this.dialogConfirm = false;
      this.dialogStokMasuk = false;
      this.dialogBuangBahan = false;
      this.inputType = "Tambah";
    },
    cancel() {
      this.resetForm();
      this.readData();
      this.dialog = false;
      this.dialogEdit = false;
      this.dialogStokMasuk = false;
      this.dialogBuangBahan = false;
      this.inputType = "Tambah";
    },
    resetForm() {
      this.form = {
        nama_bahan: "",
        unit_bahan: "",
        id_bahan: "",
        jumlah_masuk: "",
        unit_stok_bahan: "",
        harga_stok_bahan: "",
        jumlah_terbuang: "",
      };
    },
    getColor(jumlah_bahan) {
      if (jumlah_bahan < 100) return "red";
      else if (jumlah_bahan < 500) return "orange";
      else return "green";
    },
  },
  computed: {
    formTitle() {
      return this.inputType;
    },
  },
  mounted() {
    this.readData();
    this.readDataKosong();
  },
};
</script>
