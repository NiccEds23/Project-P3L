<template>
  <v-main class="list">
    <h3 class="text-h3  mb-5 font-weight-bold white--text">
      Pembayaran
    </h3>
    <v-card>
      <v-tabs v-model="currentItem" fixed-tabs slider-color="white">
        <v-tab v-for="item in items" :key="item" :href="'#tab-' + item">
          {{ item }}
        </v-tab>
      </v-tabs>
      <v-tabs-items v-model="currentItem">
        <v-tab-item value="tab-Unfinished">
          <v-card-title>
            <v-text-field
              v-model="search"
              clearable
              flat
              hide-details
              prepend-inner-icon="mdi-magnify"
              label="Search"
            ></v-text-field>
            <v-spacer></v-spacer>
          </v-card-title>
          <v-data-table
            :headers="headers"
            :items="unfinisheds"
            :search="search"
          >
            <template v-slot:[`item.actions`]="{ item }">
              <v-btn icon color="success" @click="bayar(item)">
                <v-icon> mdi-cash-register </v-icon>
              </v-btn>
              <v-btn icon color="blue" @click="editHandler(item)">
                <v-icon> mdi-pencil </v-icon>
              </v-btn>

              <v-btn icon color="red" @click="deleteHandler(item.id)">
                <v-icon> mdi-delete </v-icon>
              </v-btn>
            </template>
          </v-data-table>
        </v-tab-item>

        <v-tab-item value="tab-Finished">
          <v-card-title>
            <v-text-field
              v-model="search"
              clearable
              flat
              hide-details
              prepend-inner-icon="mdi-magnify"
              label="Search"
            ></v-text-field>
            <v-spacer></v-spacer>
          </v-card-title>
          <v-data-table :headers="headers2" :items="finisheds" :search="search">
            <template v-slot:[`item.actions`]="{ item }">
              <v-btn icon color="white" @click="detail(item)">
                <v-icon> mdi-receipt </v-icon>
              </v-btn>
              <v-btn icon color="blue" @click="editHandler(item)">
                <v-icon> mdi-pencil </v-icon>
              </v-btn>

              <v-btn icon color="red" @click="deleteHandler(item.id)">
                <v-icon> mdi-delete </v-icon>
              </v-btn>
            </template>
          </v-data-table>
        </v-tab-item>
      </v-tabs-items>
    </v-card>

    <v-dialog v-model="dialogBayar" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <span class="headline">{{ formTitle }}</span>
        </v-card-title>

        <v-card-text>
          <v-form v-model="valid" ref="form">
            <v-text-field
              v-model="form.kode_pembayaran"
              label="Kode Pembayaran"
              disabled
            ></v-text-field>

            <v-text-field
              v-model="form.nama_customer"
              label="Nama Customer"
              disabled
            ></v-text-field>

            <v-text-field
              v-model="form.no_meja"
              label="Nomor Meja"
              disabled
            ></v-text-field>

            <v-data-table
              :hide-default-footer="true"
              :headers="headerPesanans"
              :items="pesananIds"
              :search="search"
            >
              <template v-slot:[`item.harga_menu`]="{ item }">
                Rp. {{ item.harga_menu }}
              </template>
              <template v-slot:[`item.total_harga_item`]="{ item }">
                Rp. {{ item.total_harga_item }}
              </template>
            </v-data-table>

            <v-select
              v-model="form.jenis_pembayaran"
              :items="['Cash', 'Debit', 'Kredit']"
              label="Jenis Pembayaran"
              required
              :rules="unitRules"
            ></v-select>

            <v-text-field
              v-if="
                form.jenis_pembayaran == 'Kredit' ||
                  form.jenis_pembayaran == 'Debit'
              "
              v-model="form.nomor_kartu"
              label="Nomor Kartu"
              :rules="totalRules"
              required
            ></v-text-field>

            <v-text-field
              v-if="
                form.jenis_pembayaran == 'Kredit' ||
                  form.jenis_pembayaran == 'Debit'
              "
              v-model="form.nama_pemilik_kartu"
              label="Nama Pemilik Kartu"
              :rules="totalRules"
              required
            ></v-text-field>

            <v-text-field
              v-if="
                form.jenis_pembayaran == 'Kredit' ||
                  form.jenis_pembayaran == 'Debit'
              "
              v-model="form.kode_verifikasi"
              label="Kode Verifikasi"
              :rules="totalRules"
              required
            ></v-text-field>
          </v-form>
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn color="blue darken-1" text @click="cancel">
            Cancel
          </v-btn>

          <v-btn color="blue darken-1" text @click="setForm">
            Save
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogEdit" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <span class="headline">{{ formTitle }} Karyawan</span>
        </v-card-title>

        <v-card-text>
          <v-container>
            <v-text-field
              v-model="form.nama_bahan"
              label="Nama Bahan"
              required
            ></v-text-field>

            <v-select
              v-model="form.unit_bahan"
              :items="['Gr', 'Ml']"
              label="Unit bahan"
              required
            ></v-select>
          </v-container>
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn color="blue darken-1" text @click="cancel">
            Cancel
          </v-btn>

          <v-btn color="blue darken-1" text @click="update">
            Save
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogConfirm" persistent max-width="400px">
      <v-card>
        <v-card-title>
          <span class="headline">Warning!</span>
        </v-card-title>

        <v-card-text>
          Anda yakin ingin menghapus bahan ini?
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn color="blue darken-1" text @click="dialogConfirm = false">
            Cancel
          </v-btn>

          <v-btn color="blue darken-1" text @click="deleteData">
            Delete
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogStruk" persistent max-width="600">
      <v-card color="#ffffff">
        <v-toolbar color="#1E88E5" dark>Struk</v-toolbar>
        <div id="printStruk">
          <v-card-text class="mt-3 px-10 py-15 text-center">
            <div>
              <v-img
                :src="require('@/assets/akbStruk.jpg')"
                class=" mx-auto"
                max-width="500"
              />
              <hr style="height:2px" />
              <p style="float:left; text-align:left" class="mt-0 font1">
                Receipt # {{ kode_pembayaran }} <br />Waiter {{ nama }}
              </p>
              <p class="mt-0 font1" style="text-align:right">
                Date {{ tanggal_pembayaran }} <br />Time {{ time }}
              </p>
              <hr style="height:2px" />
              <p style="float:left" class="mt-0 font1 teksPosition">
                Table # {{ no_meja }}
              </p>
              <p style="text-align:right" class="mt-0 font1 teksPositionKanan1">
                Customer {{ nama_customer }}
              </p>
              <hr style="height:2px" />
              <v-data-table
                light
                :hide-default-footer="true"
                :headers="headerPesanans"
                :items="pesananIds"
                :search="search"
              >
                <template v-slot:[`item.harga_menu`]="{ item }">
                  Rp. {{ item.harga_menu }}
                </template>
                <template v-slot:[`item.total_harga_item`]="{ item }">
                  Rp. {{ item.total_harga_item }}
                </template>
              </v-data-table>
              <hr style="height:5px" />
              <p style="text-align:right" class="mb-0 font2 teksHarga">
                Sub Total Rp.{{ jumlah_pembayaran }}
              </p>
              <p style="text-align:right" class="mb-1 font2 teksHarga">
                Service 5% Rp.
              </p>
              <p style="text-align:right" class="mb-1 font2 teksHarga">
                Tax 10% Rp.
              </p>
              <hr style="height:2px" />
              <p style="text-align:right" class="mb-0 font2 teksHarga">
                Total Rp.
              </p>
              <hr style="height:2px" />
              <p style="text-align:right" class="mb-1 font3 teksHarga">
                Total Qty:
              </p>
              <p style="text-align:right" class="mb-1 font3 teksHarga">
                Total Item:
              </p>
              <p style="text-align:right" class="mb-1 font3 teksHarga">
                Printed {{ today }}
              </p>
              <p style="text-align:right" class="mb-1 font3 teksHarga">
                Cashier {{ nama_cashier }}
              </p>
              <hr style="height:2px" />
              <p style="text-align:center" class="fontBottom mt-0 mb-0">
                THANK YOU FOR YOUR VISIT
              </p>
              <hr style="height:2px" />
            </div>
          </v-card-text>
        </div>
        <v-card-actions class="justify-end">
          <v-btn text color="success" @click="dialogStruk = false">Tutup</v-btn>
          <v-btn text color="primary" @click="cetak()">Cetak</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-snackbar v-model="snackbar" :color="color" timeout="2000" bottom>
      {{ error_message }}
    </v-snackbar>
  </v-main>
</template>
<script>
import html2PDF from "jspdf-html2canvas";
import moment from "moment";
export default {
  nama_bahan: "List",
  data() {
    return {
      inputType: "Tambah",
      load: false,
      snackbar: false,
      error_message: "",
      color: "",
      search: null,
      dialogBayar: false,
      dialogEdit: false,
      dialogConfirm: false,
      dialogStruk: false,
      headers: [
        {
          text: "Nomor Meja",
          align: "start",
          sortable: true,
          value: "no_meja",
        },
        { text: "Nama Customer", value: "nama_customer" },
        { text: "Kode Pembayaran", value: "kode_pembayaran" },
        { text: "Total Pembayaran", value: "jumlah_pembayaran" },
        { text: "Actions", value: "actions" },
      ],
      headers2: [
        {
          text: "Nomor Meja",
          align: "start",
          sortable: true,
          value: "no_meja",
        },
        { text: "Nama Customer", value: "nama_customer" },
        { text: "Kode Pembayaran", value: "kode_pembayaran" },
        { text: "Jenis Pembayaran", value: "jenis_pembayaran" },
        { text: "Total Pembayaran", value: "jumlah_pembayaran" },
        { text: "Tanggal Pembayaran", value: "tanggal_pembayaran" },
        { text: "Actions", value: "actions" },
      ],
      headerPesanans: [
        {
          text: "Qty",
          align: "start",
          sortable: true,
          value: "jumlah_item",
        },
        { text: "Item Menu", value: "nama_menu" },
        { text: "Harga", value: "harga_menu" },
        { text: "SubTotal", value: "total_harga_item" },
      ],
      bahan: new FormData(),
      stokBahanMasuk: new FormData(),
      historyStokBahan: new FormData(),
      pembayarans: [],
      pembayaranIds: [],
      pesananIds: [],
      finisheds: [],
      unfinisheds: [],
      form: {
        nama_bahan: "",
        unit_bahan: "",
        id_bahan: "",
        jumlah_masuk: "",
        unit_stok_bahan: "",
        harga_stok_bahan: "",
        jumlah_terbuang: "",
      },
      deleteId: "",
      editId: "",
      detailId: "",
      bayarId: "",
      items: ["Unfinished", "Finished"],
      currentItem: "tab-Unfinished",
      date: new Date().toISOString().substr(0, 10),
      bahanRules: [(v) => !!v || "Nama Bahan tidak boleh kosong"],
      unitRules: [(v) => !!v || "Unit Bahan tidak boleh kosong"],
      jumlahRules: [(v) => !!v || "Jumlah Bahan tidak boleh kosng"],
      hargaRules: [(v) => !!v || "Harga Bahan tidak boleh kosng"],
    };
  },
  methods: {
    setForm() {
      if (this.inputType === "Tambah") {
        this.save();
      } else {
        this.update();
      }
    },
    setFormStok() {
      this.saveStok();
    },
    setFormBuang() {
      this.saveBuang();
    },
    //read data pembayaran
    readData() {
      var url = this.$api + "/pembayaran";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.pembayarans = response.data.data;
        });
    },
    //read data pembayaran unfinished
    readDataUnfinised() {
      var url = this.$api + "/pembayaranUnfinished";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.unfinisheds = response.data.data;
        });
    },
    //read data pembayaran finished
    readDataFinised() {
      var url = this.$api + "/pembayaranFinished";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.finisheds = response.data.data;
        });
    },
    getDataPembayaran() {
      var url = this.$api + "/pembayaran/" + this.detailId;
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.pembayaranIds = response.data.data;
        });
    },
    readPesananQty(id_pembayaran) {
      var url = this.$api + "/pesananqty/" + id_pembayaran;
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.qty = response.data.data;
        });
    },
    readPesananCount(id_pembayaran) {
      var url = this.$api + "/pesanancount/" + id_pembayaran;
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.counts = response.data.data;
        });
    },
    getDataPesanan(id_pembayaran) {
      var url = this.$api + "/pesanan/" + id_pembayaran;
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.pesananIds = response.data.data;
        });
    },
    //simpan data produk
    save() {
      if (this.$refs.form.validate()) {
        this.bahan.append("nama_bahan", this.form.nama_bahan);
        this.bahan.append("jumlah_bahan", "0");
        this.bahan.append("unit_bahan", this.form.unit_bahan);

        var url = this.$api + "/bahan/";
        this.load = true;
        this.$http
          .post(url, this.bahan, {
            headers: {
              Authorization: "Bearer " + localStorage.getItem("token"),
            },
          })
          .then((response) => {
            this.error_message = response.data.message;
            this.color = "green";
            this.snackbar = true;
            this.load = false;
            this.close();
            this.readData(); //mengambil data
            this.resetForm();
          })
          .catch((error) => {
            this.error_message = error.response.data.message;
            this.color = "red";
            this.snackbar = true;
            this.load = false;
          });
      }
    },
    //ubah data produk
    update() {
      let newData = {
        nama_bahan: this.form.nama_bahan,
        unit_bahan: this.form.unit_bahan,
      };
      var url = this.$api + "/bahan/" + this.editId;
      this.load = true;
      this.$http
        .put(url, newData, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          this.close();
          this.readData(); //mengambil data
          this.resetForm();
          this.inputType = "Tambah";
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    //hapus data produk
    deleteData() {
      //mengahapus data
      var url = this.$api + "/bahan/" + this.deleteId;
      //data dihapus berdasarkan id
      this.$http
        .delete(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          this.close();
          this.readData(); //mengambil data
          this.resetForm();
          this.inputType = "Tambah";
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    editHandler(item) {
      this.inputType = "Ubah";
      this.editId = item.id;
      this.form.nama_bahan = item.nama_bahan;
      this.form.unit_bahan = item.unit_bahan;
      this.dialogEdit = true;
    },
    deleteHandler(id) {
      this.deleteId = id;
      this.dialogConfirm = true;
    },
    close() {
      this.dialogBayar = false;
      this.dialogEdit = false;
      this.dialogConfirm = false;
      this.inputType = "Tambah";
    },
    cancel() {
      this.resetForm();
      this.readData();
      this.dialogBayar = false;
      this.dialogEdit = false;
      this.inputType = "Tambah";
    },
    resetForm() {
      this.form = {
        nama_bahan: "",
        unit_bahan: "",
        id_bahan: "",
        jumlah_masuk: "",
        unit_stok_bahan: "",
        harga_stok_bahan: "",
        jumlah_terbuang: "",
      };
    },
    bayar(item) {
      this.inputType = "Pembayaran";
      this.bayarId = item.id;
      this.form.kode_pembayaran = item.kode_pembayaran;
      this.form.nama_customer = item.nama_customer;
      this.form.no_meja = item.no_meja;
      this.dialogBayar = true;
      this.getDataPesanan(item.id);
    },
    detail(item) {
      this.detailId = item.id;
      this.getDataPembayaran();
      this.getDataPesanan(this.detailId);
      this.nama = item.nama;
      this.nama_cashier = localStorage.getItem("name");
      this.id = item.id;
      this.kode_pembayaran = item.kode_pembayaran;
      this.id_reservasi = item.id_reservasi;
      this.nama_customer = item.nama_customer;
      this.no_meja = item.no_meja;
      this.tanggal_pembayaran = item.tanggal_pembayaran;
      this.total = item.total;
      this.service = item.service;
      this.pajak = item.pajak;
      this.jumlah_pembayaran = item.jumlah_pembayaran;
      this.dialogStruk = true;
      this.today = moment
        .tz(moment(), "Asia/Jakarta")
        .format("MMM DD, YYYY h:mm:ss A");

      this.time = moment.tz(moment(), "Asia/Jakarta").format("HH:mm");
      this.dialogStruk = true;
    },
    cetak() {
      let print = document.getElementById("printStruk");
      html2PDF(print, {
        jsPDF: { format: "A4" },
        html2canvas: {
          scrollX: 0,
          scrollY: -window.scrollY,
        },
        output: "AKB",
      });
    },
  },
  computed: {
    formTitle() {
      return this.inputType;
    },
  },
  mounted() {
    this.readData();
    this.readDataUnfinised();
    this.readDataFinised();
    this.getDataPembayaran();
    // this.getDataPesanan();
  },
};
</script>

<style scoped>
@import url("https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@400;600&display=swap");
.v-card--reveal {
  align-items: center;
  bottom: 0;
  justify-content: center;
  opacity: 5;
  position: absolute;
  width: 100%;
}

.teksPosition {
  text-align: left;
}
.teksPositionStruk {
  text-align: left;
  margin-left: 5px;
  float: left;
}
.teksPosition2 {
  text-align: end;
}
.teksPositionKanan1 {
  text-align: right;
}
.teksPositionKananStruk {
  text-align: right;
  margin-right: 30px;
  float: right;
}
.teksHarga {
  text-align: right;
}
.teksHargaStruk {
  text-align: right;
  margin-right: 30px;
}
.myfont {
  font-family: "Roboto Slab", serif;
  color: white;
}

.fontpilih {
  font-family: "Roboto Slab", serif;
  font-size: 25px;
  color: black;
}

.font1 {
  font-family: "Fredoka One", cursive;
  font-size: 18px;
  color: black;
}
.font2 {
  font-family: "Fredoka One", cursive;
  font-size: 15px;
  color: rgb(53, 52, 52);
}
.font3 {
  font-family: "Fredoka One", cursive;
  font-size: 12px;
  color: rgb(53, 52, 52);
}

.fontqr {
  font-family: sans-serif;
  font-size: 25px;
  color: #d24848;
}

.fontBottom {
  font-family: serif;
  font-size: 18px;
  color: #000000;
}

.fontStruk {
  font-family: sans-serif;
  font-size: 15px;
}
.fontStrukHarga {
  font-family: sans-serif;
  font-size: 12px;
}

.inputnumber input::-webkit-outer-spin-button,
.inputnumber input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
  display: none;
}
</style>
