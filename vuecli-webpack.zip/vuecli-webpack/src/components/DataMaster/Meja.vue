<template>
  <v-main class="list">
    <h3 class="text-h3 font-weight-medium mb-5 font-weight-bold white--text">
      Meja
    </h3>

    <v-card>
      <v-card-title>
        <!-- <v-text-field
          v-model="search"
          append-icon="mdi-magnify"
          label="Search"
          single-line
          hide-details
        ></v-text-field> -->
        <v-switch
          v-model="tampilKosong"
          :label="`Tampil Hanya Meja Kosong`"
        ></v-switch>
        <v-spacer></v-spacer
        ><v-tooltip bottom>
          <template v-slot:activator="{ on, attrs }">
            <v-btn
              icon
              color="white"
              dark
              @click="dialogCari = true"
              v-bind="attrs"
              v-on="on"
            >
              <v-icon> mdi-magnify </v-icon>
            </v-btn>
          </template>
          <span> Cari Meja </span>
        </v-tooltip>
        <v-tooltip bottom>
          <template v-slot:activator="{ on, attrs }" v-if="role == 2">
            <v-btn
              icon
              color="success"
              dark
              @click="dialog = true"
              v-bind="attrs"
              v-on="on"
            >
              <v-icon> mdi-plus </v-icon>
            </v-btn>
          </template>
          <span> Tambah Meja </span>
        </v-tooltip>
      </v-card-title>
      <v-container v-if="tampilKosong == true">
        <v-row>
          <v-col v-for="(item, i) in mejas" :key="i" md="3">
            <v-expand-x-transition>
              <v-card
                v-if="item.status_meja == 'Available'"
                class="green accent-3"
              >
                <v-list-item-title class="headline mb-1; white--text">
                  <b> {{ item.no_meja }}</b>
                </v-list-item-title>
                <v-card-actions class="mx-auto" v-if="role == 2">
                  <v-btn
                    class="mx-2"
                    fab
                    dark
                    small
                    color="blue"
                    elevation="2"
                    @click="editHandler(item)"
                  >
                    <v-icon dark> mdi-pencil </v-icon>
                  </v-btn>

                  <v-btn
                    class="mx-2"
                    fab
                    dark
                    small
                    color="red"
                    elevation="2"
                    @click="deleteHandler(item.id)"
                  >
                    <v-icon> mdi-delete </v-icon>
                  </v-btn>
                </v-card-actions>
              </v-card>
            </v-expand-x-transition>
          </v-col>
        </v-row>
      </v-container>

      <v-container v-if="tampilKosong == false">
        <v-row>
          <v-col v-for="(item, i) in mejas" :key="i" md="3">
            <v-expand-x-transition>
              <v-card
                v-if="item.status_meja == 'Available'"
                class="green accent-3"
              >
                <v-list-item-title class="headline mb-1; white--text">
                  <b> {{ item.no_meja }}</b>
                </v-list-item-title>
                <v-card-actions class="mx-auto" v-if="role == 2">
                  <v-btn
                    class="mx-2"
                    fab
                    dark
                    small
                    color="blue"
                    elevation="2"
                    @click="editHandler(item)"
                  >
                    <v-icon dark> mdi-pencil </v-icon>
                  </v-btn>

                  <v-btn
                    class="mx-2"
                    fab
                    dark
                    small
                    color="red"
                    elevation="2"
                    @click="deleteHandler(item.id)"
                  >
                    <v-icon dark> mdi-delete </v-icon>
                  </v-btn>
                </v-card-actions>
              </v-card>

              <v-card
                justify="center"
                v-else-if="item.status_meja == 'Unavailable'"
                class="red darken-3"
              >
                <v-list-item-title class="headline mb-1; white--text">
                  <b> {{ item.no_meja }}</b>
                </v-list-item-title>
                <v-card-actions class="mx-auto" v-if="role == 2">
                  <v-btn
                    class="mx-2"
                    fab
                    dark
                    small
                    color="blue"
                    elevation="2"
                    @click="editHandler(item)"
                  >
                    <v-icon> mdi-pencil </v-icon>
                  </v-btn>

                  <v-btn
                    class="mx-2"
                    fab
                    dark
                    small
                    color="red"
                    elevation="2"
                    @click="deleteHandler(item.id)"
                  >
                    <v-icon> mdi-delete </v-icon>
                  </v-btn>
                </v-card-actions>
              </v-card>
            </v-expand-x-transition>
          </v-col>
        </v-row>
      </v-container>
    </v-card>

    <v-dialog v-model="dialog" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <span class="headline">{{ formTitle }} Meja</span>
        </v-card-title>

        <v-card-text>
          <v-form v-model="valid" ref="form">
            <v-text-field
              v-model="form.no_meja"
              label="Nomor Meja"
              required
              :rules="noMejaRules"
            ></v-text-field>

            <!-- <v-select
              v-model="form.status_meja"
              :items="['Available', 'Unavailable']"
              label="Status Meja"
              required
            ></v-select> -->
          </v-form>
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn color="blue darken-1" text @click="cancel">
            Cancel
          </v-btn>

          <v-btn color="blue darken-1" text @click="setForm">
            Save
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogEdit" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <span class="headline">{{ formTitle }} Meja</span>
        </v-card-title>

        <v-card-text>
          <v-container>
            <v-text-field
              v-model="form.no_meja"
              label="No Meja"
              required
            ></v-text-field>

            <!-- <v-select
              v-model="form.status_meja"
              :items="['Available', 'Unavailable']"
              label="Status Meja"
              required
            ></v-select> -->
          </v-container>
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn color="blue darken-1" text @click="cancel">
            Cancel
          </v-btn>

          <v-btn color="blue darken-1" text @click="update">
            Save
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogConfirm" max-width="600px">
      <v-card>
        <v-card-title>
          <span class="headline">Warning!</span>
        </v-card-title>

        <v-card-text>
          Anda yakin ingin menghapus Meja ini?
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn color="blue darken-1" text @click="dialogConfirm = false">
            Cancel
          </v-btn>

          <v-btn color="blue darken-1" text @click="deleteData">
            Delete
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogCari" persistent max-width="600px">
      <v-card>
        <v-data-table :headers="headers" :items="mejas" :search="search">
          <template v-slot:top>
            <v-text-field
              append-icon="mdi-magnify"
              v-model="search"
              label="Search meja"
              class="mx-4"
            ></v-text-field>
          </template>
          <template v-slot:[`item.actions`]="{ item }" v-if="role == 2">
            <v-btn
              v-b-tooltip.hover.left="'Edit'"
              icon
              small
              class="mr-2"
              @click="editHandler(item)"
            >
              <v-icon>mdi-pencil</v-icon>
            </v-btn>

            <v-btn
              v-b-tooltip.hover.right="'Hapus'"
              icon
              small
              @click="deleteHandler(item.id)"
            >
              <v-icon color="red">mdi-delete</v-icon>
            </v-btn>
          </template>
        </v-data-table>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="tutupCari">
            Back
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-snackbar v-model="snackbar" :color="color" timeout="2000" bottom>
      {{ error_message }}
    </v-snackbar>
  </v-main>
</template>
<script>
export default {
  no_meja: "List",
  data() {
    return {
      inputType: "Tambah",
      load: false,
      snackbar: false,
      error_message: "",
      color: "",
      search: null,
      dialog: false,
      dialogEdit: false,
      dialogConfirm: false,
      headers: [
        {
          text: "Nomor Meja",
          align: "start",
          sortable: true,
          value: "no_meja",
        },
        { text: "Status Meja", value: "status_meja" },
        { text: "Actions", value: "actions" },
      ],
      meja: new FormData(),
      mejas: [],
      form: {
        no_meja: "",
        // status_meja: "",
      },
      deleteId: "",
      editId: "",
      tampilKosong: false,
      dialogCari: false,
      role: "",
      noMejaRules: [(v) => !!v || "Nomor Meja tidak boleh kosong"],
    };
  },
  methods: {
    setForm() {
      if (this.inputType === "Tambah") {
        this.save();
      } else {
        this.update();
      }
    },
    //read data meja
    readData() {
      var url = this.$api + "/meja";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.mejas = response.data.data;
        });
    },
    //simpan data produk
    save() {
      if (this.$refs.form.validate()) {
        this.meja.append("no_meja", this.form.no_meja);
        this.meja.append("status_meja", "Available");

        var url = this.$api + "/meja/";
        this.load = true;
        this.$http
          .post(url, this.meja, {
            headers: {
              Authorization: "Bearer " + localStorage.getItem("token"),
            },
          })
          .then((response) => {
            this.error_message = response.data.message;
            this.color = "green";
            this.snackbar = true;
            this.load = false;
            this.close();
            this.readData(); //mengambil data
            this.resetForm();
          })
          .catch((error) => {
            this.error_message = error.response.data.message;
            this.color = "red";
            this.snackbar = true;
            this.load = false;
          });
      }
    },
    //ubah data produk
    update() {
      let newData = {
        no_meja: this.form.no_meja,
        status_meja: this.form.status_meja,
        notelp_meja: this.form.notelp_meja,
      };
      var url = this.$api + "/meja/" + this.editId;
      this.load = true;
      this.$http
        .put(url, newData, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          this.close();
          this.readData(); //mengambil data
          this.resetForm();
          this.inputType = "Tambah";
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    //hapus data produk
    deleteData() {
      //mengahapus data
      var url = this.$api + "/meja/" + this.deleteId;
      //data dihapus berdasarkan id
      this.$http
        .delete(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          this.close();
          this.readData(); //mengambil data
          this.resetForm();
          this.inputType = "Tambah";
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    editHandler(item) {
      this.inputType = "Ubah";
      this.editId = item.id;
      this.form.no_meja = item.no_meja;
      this.form.status_meja = item.status_meja;
      this.form.notelp_meja = item.notelp_meja;
      this.dialogEdit = true;
    },
    deleteHandler(id) {
      this.deleteId = id;
      this.dialogConfirm = true;
    },
    close() {
      this.dialog = false;
      this.dialogEdit = false;
      this.dialogConfirm = false;
      this.inputType = "Tambah";
    },
    cancel() {
      this.resetForm();
      this.readData();
      this.dialog = false;
      this.dialogEdit = false;
      this.inputType = "Tambah";
    },
    resetForm() {
      this.form = {
        no_meja: "",
        // status_meja: "",
      };
    },
    tutupCari() {
      this.dialogCari = false;
      this.search = "";
    },
  },
  computed: {
    formTitle() {
      return this.inputType;
    },
  },
  mounted() {
    this.readData();
    this.role = localStorage.getItem("role");
  },
};
</script>
