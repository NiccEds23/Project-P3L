<template>
  <v-main class="list">
    <h3 class="text-h3 font-weight-medium mb-5 font-weight-bold white--text">
      History Bahan
    </h3>

    <v-card>
      <!-- <v-tabs v-model="tabs" class="font-weight" fixed-tabs>
        <v-tab>
          Stok Bahan
        </v-tab>
        <v-tab>
          Bahan Masuk
        </v-tab>
        <v-tab>
          Bahan Keluar
        </v-tab>
        <v-tab>
          Bahan Terbuang
        </v-tab>
      </v-tabs> -->
      <v-tabs v-model="currentItem" fixed-tabs slider-color="white">
        <v-tab v-for="item in items" :key="item" :href="'#tab-' + item">
          {{ item }}
        </v-tab>
      </v-tabs>
      <v-tabs-items v-model="currentItem">
        <v-tab-item value="tab-Stok Bahan">
          <v-card-title>
            <v-text-field
              v-model="search"
              clearable
              flat
              hide-details
              prepend-inner-icon="mdi-magnify"
              label="Search"
            ></v-text-field>
            <v-spacer></v-spacer>
          </v-card-title>
          <v-data-table
            :headers="headersStok"
            :items="stokBahans"
            :search="search"
          >
            <!-- <template v-slot:[`item.jumlah_bahan`]="{ item }">
              <v-chip :color="getColor(item.jumlah_bahan)" dark>
                {{ item.jumlah_bahan }}
              </v-chip>
            </template> -->
            <template v-slot:[`item.actions`]="{ item }">
              <v-btn icon color="blue" @click="editHandler(item)">
                <v-icon> mdi-pencil </v-icon>
              </v-btn>

              <v-btn icon color="red" @click="deleteHandler(item.id)">
                <v-icon> mdi-delete </v-icon>
              </v-btn>
            </template>
          </v-data-table>
        </v-tab-item>

        <v-tab-item value="tab-Bahan Masuk">
          <v-card-title>
            <v-text-field
              v-model="search"
              clearable
              flat
              hide-details
              prepend-inner-icon="mdi-magnify"
              label="Search"
            ></v-text-field>
            <v-spacer></v-spacer>
          </v-card-title>
          <v-data-table
            :headers="headersMasuk"
            :items="bahanMasuks"
            :search="search"
          >
            <!-- <template v-slot:[`item.jumlah_bahan`]="{ item }">
              <v-chip :color="getColor(item.jumlah_bahan)" dark>
                {{ item.jumlah_bahan }}
              </v-chip>
            </template> -->
            <template v-slot:[`item.actions`]="{ item }">
              <v-btn icon color="blue" @click="editHandler(item)">
                <v-icon> mdi-pencil </v-icon>
              </v-btn>

              <v-btn icon color="red" @click="deleteHandler(item.id)">
                <v-icon> mdi-delete </v-icon>
              </v-btn>
            </template>
          </v-data-table>
        </v-tab-item>

        <v-tab-item value="tab-Bahan Keluar">
          <v-card-title>
            <v-text-field
              v-model="search"
              clearable
              flat
              hide-details
              prepend-inner-icon="mdi-magnify"
              label="Search"
            ></v-text-field>
            <v-spacer></v-spacer>
          </v-card-title>
          <v-data-table
            :headers="headersKeluar"
            :items="bahanKeluars"
            :search="search"
          >
            <!-- <template v-slot:[`item.jumlah_bahan`]="{ item }">
              <v-chip :color="getColor(item.jumlah_bahan)" dark>
                {{ item.jumlah_bahan }}
              </v-chip>
            </template> -->
          </v-data-table>
        </v-tab-item>

        <v-tab-item value="tab-Bahan Terbuang">
          <v-card-title>
            <v-text-field
              v-model="search"
              clearable
              flat
              hide-details
              prepend-inner-icon="mdi-magnify"
              label="Search"
            ></v-text-field>
            <v-spacer></v-spacer>
          </v-card-title>
          <v-data-table
            :headers="headersTerbuang"
            :items="bahanTerbuangs"
            :search="search"
          >
            <!-- <template v-slot:[`item.jumlah_bahan`]="{ item }">
              <v-chip :color="getColor(item.jumlah_bahan)" dark>
                {{ item.jumlah_bahan }}
              </v-chip>
            </template> -->
          </v-data-table>
        </v-tab-item>

        <v-tab-item value="tab-Full History">
          <v-card-title>
            <v-text-field
              v-model="search"
              clearable
              flat
              hide-details
              prepend-inner-icon="mdi-magnify"
              label="Search"
            ></v-text-field>
            <v-spacer></v-spacer>
          </v-card-title>
          <v-data-table
            :headers="headersHistory"
            :items="historys"
            :search="search"
          >
            <!-- <template v-slot:[`item.jumlah_bahan`]="{ item }">
              <v-chip :color="getColor(item.jumlah_bahan)" dark>
                {{ item.jumlah_bahan }}
              </v-chip>
            </template> -->
            <template v-slot:[`item.actions`]="{ item }">
              <v-btn icon color="blue" @click="editHandler(item)">
                <v-icon> mdi-pencil </v-icon>
              </v-btn>

              <v-btn icon color="red" @click="deleteHandler(item.id)">
                <v-icon> mdi-delete </v-icon>
              </v-btn>
            </template>
          </v-data-table>
        </v-tab-item>
      </v-tabs-items>
    </v-card>

    <v-dialog v-model="dialogEdit" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <span class="headline">{{ formTitle }} Stok Bahan</span>
        </v-card-title>

        <v-card-text>
          <v-container>
            <v-select
              v-model="form.id_bahan"
              :items="bahans"
              item-text="nama_bahan"
              item-value="id"
              label="Nama Bahan"
              required
            ></v-select>

            <v-text-field
              v-model="form.jumlah_masuk"
              label="Jumlah Bahan"
              required
            ></v-text-field>

            <v-select
              v-model="form.unit_stok_bahan"
              :items="['Gr', 'Ml']"
              label="Unit bahan"
              required
            ></v-select>

            <v-text-field
              v-model="form.harga_stok_bahan"
              label="Harga Bahan"
              prefix="Rp "
              required
            ></v-text-field>
          </v-container>
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn color="blue darken-1" text @click="cancel">
            Cancel
          </v-btn>

          <v-btn color="blue darken-1" text @click="update">
            Save
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogConfirm" persistent max-width="400px">
      <v-card>
        <v-card-title>
          <span class="headline">Warning!</span>
        </v-card-title>

        <v-card-text>
          Anda yakin ingin menghapus bahan ini?
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn color="blue darken-1" text @click="dialogConfirm = false">
            Cancel
          </v-btn>

          <v-btn color="blue darken-1" text @click="deleteData">
            Delete
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-snackbar v-model="snackbar" :color="color" timeout="2000" bottom>
      {{ error_message }}
    </v-snackbar>
  </v-main>
</template>
<script>
export default {
  nama_bahan: "List",
  data() {
    return {
      inputType: "Tambah",
      load: false,
      snackbar: false,
      error_message: "",
      color: "",
      search: null,
      dialog: false,
      dialogEdit: false,
      dialogConfirm: false,
      dialogStokMasuk: false,
      dialogBuangBahan: false,
      headersStok: [
        {
          text: "Nama Bahan",
          align: "start",
          sortable: true,
          value: "nama_bahan",
        },
        {
          text: "Nama Karyawan",
          value: "name",
        },
        { text: "Jumlah Masuk", value: "jumlah_masuk" },
        { text: "Unit Bahan", value: "unit_stok_bahan" },
        { text: "Harga Bahan", value: "harga_stok_bahan" },
        { text: "Tanggal Masuk", value: "tanggal_history" },
        { text: "Actions", value: "actions" },
      ],
      headersMasuk: [
        {
          text: "Nama Bahan",
          align: "start",
          sortable: true,
          value: "nama_bahan",
        },
        {
          text: "Nama Karyawan",
          value: "name",
        },
        { text: "Jumlah Masuk", value: "jumlah_masuk" },
        { text: "Jumlah Sisa", value: "jumlah_sisa" },
        { text: "Tanggal Masuk", value: "tanggal_history" },
      ],
      headersKeluar: [
        {
          text: "Nama Bahan",
          align: "start",
          sortable: true,
          value: "nama_bahan",
        },
        {
          text: "Nama Karyawan",
          value: "name",
        },
        { text: "Jumlah Keluar", value: "jumlah_keluar" },
        { text: "Jumlah Sisa", value: "jumlah_sisa" },
        { text: "Tanggal Keluar", value: "tanggal_history" },
      ],
      headersTerbuang: [
        {
          text: "Nama Bahan",
          align: "start",
          sortable: true,
          value: "nama_bahan",
        },
        {
          text: "Nama Karyawan",
          value: "name",
        },
        { text: "Jumlah Terbuang", value: "jumlah_terbuang" },
        { text: "Jumlah Sisa", value: "jumlah_sisa" },
        { text: "Tanggal Terbuang", value: "tanggal_history" },
      ],
      headersHistory: [
        {
          text: "Nama Bahan",
          align: "start",
          sortable: true,
          value: "nama_bahan",
        },
        {
          text: "Nama Karyawan",
          value: "name",
        },
        { text: "Jumlah Masuk", value: "jumlah_masuk" },
        { text: "Jumlah Keluar", value: "jumlah_keluar" },
        { text: "Jumlah Terbuang", value: "jumlah_terbuang" },
        { text: "Jumlah Sisa", value: "jumlah_sisa" },
        { text: "Tanggal Keluar", value: "tanggal_history" },
      ],
      bahans: [],
      stokBahans: [],
      bahanMasuks: [],
      bahanKeluars: [],
      bahanTerbuangs: [],
      historys: [],
      form: {
        id_bahan: "",
        jumlah_masuk: "",
        unit_stok_bahan: "",
        harga_stok_bahan: "",
        jumlah_terbuang: "",
      },
      deleteId: "",
      editId: "",
      items: ["Stok Bahan", "Bahan Keluar", "Bahan Terbuang", "Full History"],
      currentItem: "tab-Stok Bahan",
      headers: "",
      itemTable: "",
      //   date: new Date().toISOString().substr(0, 10),
      bahanRules: [(v) => !!v || "Nama Bahan tidak boleh kosong"],
      unitRules: [(v) => !!v || "Unit Bahan tidak boleh kosong"],
      jumlahRules: [(v) => !!v || "Jumlah Bahan tidak boleh kosng"],
      hargaRules: [(v) => !!v || "Harga Bahan tidak boleh kosng"],
    };
  },
  methods: {
    setForm() {
      if (this.inputType === "Tambah") {
        this.save();
      } else {
        this.update();
      }
    },
    setFormStok() {
      this.saveStok();
    },
    setFormBuang() {
      this.saveBuang();
    },
    //read data bahan
    readData() {
      var url = this.$api + "/bahan";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.bahans = response.data.data;
        });
    },
    //read data stok bahan
    readDataStok() {
      var url = this.$api + "/stokBahanMasuk";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.stokBahans = response.data.data;
        });
    },
    //read data masuk
    readDataMasuk() {
      var url = this.$api + "/historyStokBahanMasuk";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.bahanMasuks = response.data.data;
        });
    },
    //read data keluar
    readDataKeluar() {
      var url = this.$api + "/historyStokBahanKeluar";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.bahanKeluars = response.data.data;
        });
    },
    //read data terbuang
    readDataTerbuang() {
      var url = this.$api + "/historyStokBahanTerbuang";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.bahanTerbuangs = response.data.data;
        });
    },
    //read data history
    readDataHistory() {
      var url = this.$api + "/historyStokBahan";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.historys = response.data.data;
        });
    },
    //ubah data produk
    update() {
      let newData = {
        id_bahan: this.form.id_bahan,
        jumlah_masuk: this.form.jumlah_masuk,
        unit_stok_bahan: this.form.unit_stok_bahan,
        harga_stok_bahan: this.form.harga_stok_bahan,
      };
      var url = this.$api + "/stokBahanMasuk/" + this.editId;
      this.load = true;
      this.$http
        .put(url, newData, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          this.close();
          this.readDataStok(); //mengambil data
          this.resetForm();
          this.inputType = "Tambah";
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    //hapus data produk
    deleteData() {
      //mengahapus data
      var url = this.$api + "/stokBahanMasuk/" + this.deleteId;
      //data dihapus berdasarkan id
      this.$http
        .delete(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          this.close();
          this.readData(); //mengambil data
          this.resetForm();
          this.inputType = "Tambah";
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    editHandler(item) {
      this.inputType = "Ubah";
      this.editId = item.id;
      this.form.id_bahan = item.id_bahan;
      this.form.jumlah_masuk = item.jumlah_masuk;
      this.form.unit_stok_bahan = item.unit_stok_bahan;
      this.form.harga_stok_bahan = item.harga_stok_bahan;
      this.dialogEdit = true;
    },
    deleteHandler(id) {
      this.deleteId = id;
      this.dialogConfirm = true;
    },
    close() {
      this.dialog = false;
      this.dialogEdit = false;
      this.dialogConfirm = false;
      this.dialogStokMasuk = false;
      this.dialogBuangBahan = false;
      this.inputType = "Tambah";
    },
    cancel() {
      this.resetForm();
      this.readData();
      this.dialog = false;
      this.dialogEdit = false;
      this.dialogStokMasuk = false;
      this.dialogBuangBahan = false;
      this.inputType = "Tambah";
    },
    resetForm() {
      this.form = {
        id_bahan: "",
        jumlah_masuk: "",
        unit_stok_bahan: "",
        harga_stok_bahan: "",
        jumlah_terbuang: "",
      };
    },
    addItem(item) {
      const removed = this.items.splice(0, 1);
      this.items.push(...this.more.splice(this.more.indexOf(item), 1));
      this.more.push(...removed);
      this.$nextTick(() => {
        this.currentItem = "tab-" + item;
      });
    },
    // getColor(jumlah_bahan) {
    //   if (jumlah_bahan < 100) return "red";
    //   else if (jumlah_bahan < 500) return "orange";
    //   else return "green";
    // },
  },
  computed: {
    formTitle() {
      return this.inputType;
    },
  },
  mounted() {
    this.readData();
    this.readDataStok();
    this.readDataMasuk();
    this.readDataKeluar();
    this.readDataTerbuang();
    this.readDataHistory();
  },
};
</script>
