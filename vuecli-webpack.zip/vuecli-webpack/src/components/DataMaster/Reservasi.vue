<template>
  <v-main class="list">
    <h3 class="text-h3 font-weight-medium mb-5 font-weight-bold white--text">
      Reservasi
    </h3>

    <v-card>
      <v-card-title>
        <v-text-field
          v-model="search"
          append-icon="mdi-magnify"
          label="Search"
          single-line
          hide-details
        ></v-text-field>

        <v-spacer></v-spacer>

        <v-tooltip bottom>
          <template v-slot:activator="{ on, attrs }">
            <v-btn
              icon
              color="success"
              dark
              @click="dialogCustomer = true"
              v-bind="attrs"
              v-on="on"
            >
              <v-icon> mdi-plus </v-icon>
            </v-btn>
          </template>
          <span> Tambah Reservasi </span>
        </v-tooltip>
      </v-card-title>

      <v-data-table :headers="headers" :items="reservasis" :search="search">
        <template v-slot:[`item.actions`]="{ item }">
          <v-btn
            icon
            color="white"
            :disabled="item.status_reservasi == 'Finished'"
            @click="showQR(item)"
          >
            <v-icon> mdi-qrcode </v-icon>
          </v-btn>
          <v-btn icon color="blue" @click="editHandler(item)">
            <v-icon> mdi-pencil </v-icon>
          </v-btn>

          <v-btn icon color="red" @click="deleteHandler(item.id)">
            <v-icon> mdi-delete </v-icon>
          </v-btn>
        </template>
      </v-data-table>
    </v-card>

    <v-dialog v-model="dialog" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <span class="headline">{{ formTitle }} reservasi</span>
        </v-card-title>

        <v-card-text>
          <v-form v-model="valid" ref="form">
            <v-select
              v-model="form.id_customer"
              :items="customers"
              item-text="nama_customer"
              item-value="id"
              label="Nama Customer"
              required
              :rules="namaCustomerRules"
            ></v-select>

            <v-select
              v-model="form.id_meja"
              :items="mejas"
              item-text="no_meja"
              item-value="id"
              label="No Meja"
              required
              :rules="noMejaRules"
            ></v-select>

            <v-select
              v-model="form.sesi_reservasi"
              :items="['Lunch', 'Dinner']"
              label="Sesi Reservasi"
              required
              :rules="sesiRules"
            ></v-select>

            <v-menu
              v-model="menu"
              :close-on-content-click="false"
              :nudge-right="40"
              transition="scale-transition"
              offset-y
              min-width="auto"
            >
              <template v-slot:activator="{ on, attrs }">
                <v-text-field
                  v-model="date"
                  label="Tanggal Kunjung"
                  prepend-icon="mdi-calendar"
                  readonly
                  v-bind="attrs"
                  v-on="on"
                  :rules="tanggalKunjungRules"
                ></v-text-field>
              </template>
              <v-date-picker
                v-model="date"
                @input="menu = false"
              ></v-date-picker>
            </v-menu>

            <!-- <v-select
              v-model="form.status_reservasi"
              :items="['Finished', 'Unfinished']"
              label="Status Reservasi"
              required
            ></v-select> -->
          </v-form>
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn color="blue darken-1" text @click="cancel">
            Cancel
          </v-btn>

          <v-btn color="blue darken-1" text @click="setForm">
            Save
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogCustomer" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <span class="headline">{{ formTitle }} Customer</span>
        </v-card-title>

        <v-card-text>
          <v-form v-model="valid" ref="form">
            <v-text-field
              v-model="form.nama_customer"
              label="Nama"
              required
              :rules="namaCustomerRules"
            ></v-text-field>

            <v-text-field
              v-model="form.email_customer"
              label="Email customer"
              required
            ></v-text-field>

            <v-text-field
              v-model="form.notelp_customer"
              label="Nomor Telepon"
              required
            ></v-text-field>
          </v-form>
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn color="blue darken-1" text @click="cancel">
            Cancel
          </v-btn>

          <v-btn color="blue darken-1" text @click="setFormCustomer">
            Save
          </v-btn>

          <v-btn color="blue darken-1" text @click="next">
            Next
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogEdit" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <span class="headline">{{ formTitle }} reservasi</span>
        </v-card-title>

        <v-card-text>
          <v-container>
            <v-select
              v-model="form.id_customer"
              :items="customers"
              item-text="nama_customer"
              item-value="id"
              label="Nama Customer"
              required
            ></v-select>

            <v-select
              v-model="form.id_meja"
              :items="mejas"
              item-text="no_meja"
              item-value="id"
              label="No Meja"
              required
              :rules="mejaRules"
            ></v-select>

            <v-select
              v-model="form.sesi_reservasi"
              :items="['Lunch', 'Dinner']"
              label="Sesi Reservasi"
              required
            ></v-select>

            <v-menu
              v-model="menu2"
              :close-on-content-click="false"
              :nudge-right="40"
              transition="scale-transition"
              offset-y
              min-width="auto"
            >
              <template v-slot:activator="{ on, attrs }">
                <v-text-field
                  v-model="dateUp"
                  label="Tanggal Kunjung"
                  prepend-icon="mdi-calendar"
                  readonly
                  v-bind="attrs"
                  v-on="on"
                ></v-text-field>
              </template>
              <v-date-picker
                v-model="dateUp"
                @input="menu2 = false"
              ></v-date-picker>
            </v-menu>

            <v-select
              v-model="form.status_reservasi"
              :items="['Finished', 'Unfinished']"
              label="Status Reservasi"
              required
            ></v-select>
          </v-container>
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn color="blue darken-1" text @click="cancel">
            Cancel
          </v-btn>

          <v-btn color="blue darken-1" text @click="update">
            Save
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogConfirm" persistent max-width="400px">
      <v-card>
        <v-card-title>
          <span class="headline">Warning!</span>
        </v-card-title>

        <v-card-text>
          Anda yakin ingin menghapus reservasi ini?
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn color="blue darken-1" text @click="dialogConfirm = false">
            Cancel
          </v-btn>

          <v-btn color="blue darken-1" text @click="deleteData">
            Delete
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog
      data-aos="zoom-in"
      v-model="dialogqr"
      persistent
      max-width="500px"
    >
      <template>
        <v-card class="mx-auto" color="#00897B" dark>
          <v-toolbar color="#64B5F6" dark>QR Code</v-toolbar>
          <v-card-text class="mt-5 px-10 text-center">
            <v-img
              data-aos="zoom-in"
              :src="$image + 'logofull.png'"
              class="mx-auto"
              max-width="200"
            />
            <p class="fontqr mt-5 mb-5">AKB RESTO</p>
            <qrcode-vue :value="value" :size="size" level="H" />
            <p class="mt-5 font1">Printed {{ hari_ini }}</p>
            <p class="mb-5 font2">Printed by {{ qr.nama }}</p>
            <v-spacer></v-spacer>
            <p class="fontBottom mt-5 mb-5">
              ---------------------------------------------
            </p>
            <p class="fontBottom mt-5 mb-5">FUN PLACE TO GRILL</p>
            <p class="fontBottom mt-5 mb-5">
              ---------------------------------------------
            </p>
          </v-card-text>
          <v-card-actions class="justify-end">
            <v-btn text color="success" @click="dialogqr = false">Tutup</v-btn>
            <v-btn text color="primary" @click="cetak()">Cetak</v-btn>
          </v-card-actions>
        </v-card>
      </template>
    </v-dialog>

    <template>
      <div>
        <vue-html2pdf
          :show-layout="false"
          :float-layout="true"
          :enable-download="true"
          :preview-modal="true"
          :paginate-elements-by-height="1400"
          :filename="
            'ReservasiQR-' +
              id_customer +
              '-' +
              id_reservasi +
              '-' +
              id_karyawan
          "
          :pdf-quality="1"
          :manual-pagination="false"
          pdf-format="a5"
          pdf-orientation="portrait"
          pdf-content-width="500px"
          pdf-content-height="700px"
          @progress="onProgress($event)"
          @hasStartedGeneration="hasStartedGeneration()"
          @hasGenerated="hasGenerated($event)"
          ref="html2Pdf"
        >
          <section slot="pdf-content" class="text-center mt-8">
            <img
              :src="image.sample"
              class="mx-auto mt-5"
              style="max-width:200px"
            />
            <qrcode-vue :value="value" :size="size" level="H" />
            <p class="mt-1 font1Print">Printed {{ hari_ini }}</p>
            <p class="mb-1 font2Print">Printed by {{ qr.nama }}</p>
            <p class="fontBottomPrint mt-1 mb-1">
              ---------------------------------------------
            </p>
            <p class="fontBottomPrint mt-1 mb-1">FUN PLACE TO GRILL</p>
            <p class="fontBottomPrint mt-1 mb-1">
              ---------------------------------------------
            </p>
          </section>
        </vue-html2pdf>
      </div>
    </template>

    <v-snackbar v-model="snackbar" :color="color" timeout="2000" bottom>
      {{ error_message }}
    </v-snackbar>
  </v-main>
</template>
<script>
import moment from "moment";
import QrcodeVue from "qrcode.vue";
import VueHtml2pdf from "vue-html2pdf";
export default {
  id_customer: "List",
  data() {
    return {
      image: {
        sample: require("@/assets/logofull.png"),
      },
      inputType: "Tambah",
      load: false,
      snackbar: false,
      error_message: "",
      color: "",
      search: null,
      dialog: false,
      dialogCustomer: false,
      dialogEdit: false,
      dialogConfirm: false,
      dialogqr: false,
      headers: [
        {
          text: "Nama Customer",
          align: "start",
          sortable: true,
          value: "nama_customer",
        },
        { text: "No Meja", value: "no_meja" },
        { text: "Karyawan", value: "nama_karyawan" },
        { text: "Sesi Reservasi", value: "sesi_reservasi" },
        { text: "Status Reservasi", value: "status_reservasi" },
        { text: "Tanggal Reservasi", value: "created_at" },
        { text: "Tanggal Kunjung", value: "tanggal_kunjung_reservasi" },
        { text: "Actions", value: "actions" },
      ],
      reservasi: new FormData(),
      customer: new FormData(),
      reservasis: [],
      form: {
        id_customer: "",
        id_meja: null,
        sesi_reservasi: "",
        status_reservasi: null,
        date: "",
        dateUp: "",
        tanggal_reservasi: "",
        nama_customer: "",
        email_customer: "",
        notelp_customer: "",
      },
      deleteId: "",
      editId: "",
      customers: [],
      mejas: [],
      mejasfull: [],
      karyawans: [],
      date: new Date().toISOString().substr(0, 10),
      dateUp: "",
      menu: false,
      menu2: false,
      value: null,
      size: 200,
      qr: [],
      hari_ini: null,
      noMejaRules: [(v) => !!v || "Nomor Meja tidak boleh kosong"],
      namaCustomerRules: [(v) => !!v || "Customer tidak boleh kosong"],
      sesiRules: [(v) => !!v || "Sesi tidak boleh kosong"],
      tanggalKunjungRules: [(v) => !!v || "Tanggal Kunjung tidak boleh kosong"],
      statusRules: [(v) => !!v || "Status tidak boleh kosong"],
    };
  },
  components: {
    QrcodeVue,
    VueHtml2pdf,
  },
  methods: {
    setForm() {
      if (this.inputType === "Tambah") {
        this.save();
      } else {
        this.update();
      }
    },
    setFormCustomer() {
      this.saveCustomer();
    },
    //read data reservasi
    readData() {
      var url = this.$api + "/reservasi";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.reservasis = response.data.data;
        });
    },
    //read data customer
    readDataCustomer() {
      var url = this.$api + "/customer";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.customers = response.data.data;
        });
    },
    //read data meja
    readDataMeja() {
      var url = this.$api + "/meja";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.mejas = response.data.data;
        });
    },
    //read data meja full
    // readDataMejaFull() {
    //   var url = this.$api + "/meja";
    //   this.$http
    //     .get(url, {
    //       headers: {
    //         Authorization: "Bearer " + localStorage.getItem("token"),
    //       },
    //     })
    //     .then((response) => {
    //       this.mejasfull = response.data.data;
    //     });
    // },
    //read data karyawan
    readDataKaryawan() {
      var url = this.$api + "/karyawan";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.karyawans = response.data.data;
        });
    },
    //simpan data reservasi
    save() {
      if (this.$refs.form.validate()) {
        this.reservasi.append("id_customer", this.form.id_customer);
        this.reservasi.append("id_meja", this.form.id_meja);
        this.reservasi.append("id_karyawan", localStorage.getItem("id"));
        this.reservasi.append("sesi_reservasi", this.form.sesi_reservasi);
        this.reservasi.append("tanggal_kunjung_reservasi", this.date);
        this.reservasi.append("status_reservasi", "Unfinished");

        var url = this.$api + "/reservasi/";
        this.load = true;
        this.$http
          .post(url, this.reservasi, {
            headers: {
              Authorization: "Bearer " + localStorage.getItem("token"),
            },
          })
          .then((response) => {
            this.error_message = response.data.message;
            this.color = "green";
            this.snackbar = true;
            this.load = false;
            this.close();
            this.readData(); //mengambil data
            this.resetForm();
          })
          .catch((error) => {
            this.error_message = error.response.data.message;
            this.color = "red";
            this.snackbar = true;
            this.load = false;
          });
      }
    },
    //simpan data customer
    saveCustomer() {
      if (this.$refs.form.validate()) {
        this.customer.append("nama_customer", this.form.nama_customer);
        this.customer.append("email_customer", this.form.email_customer);
        this.customer.append("notelp_customer", this.form.notelp_customer);

        var url = this.$api + "/customer/";
        this.load = true;
        this.$http
          .post(url, this.customer, {
            headers: {
              Authorization: "Bearer " + localStorage.getItem("token"),
            },
          })
          .then((response) => {
            this.error_message = response.data.message;
            this.color = "green";
            this.snackbar = true;
            this.load = false;
            this.next();
            this.readData(); //mengambil data
            this.resetForm();
          })
          .catch((error) => {
            this.error_message = error.response.data.message;
            this.color = "red";
            this.snackbar = true;
            this.load = false;
          });
      }
    },
    //ubah data produk
    update() {
      let newData = {
        id_customer: this.form.id_customer,
        id_meja: this.form.id_meja,
        sesi_reservasi: this.form.sesi_reservasi,
        status_reservasi: this.form.status_reservasi,
        tanggal_kunjung_reservasi: this.date,
      };
      var url = this.$api + "/reservasi/" + this.editId;
      this.load = true;
      this.$http
        .put(url, newData, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          this.close();
          this.readData(); //mengambil data
          this.resetForm();
          this.inputType = "Tambah";
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    //hapus data produk
    deleteData() {
      //mengahapus data
      var url = this.$api + "/reservasi/" + this.deleteId;
      //data dihapus berdasarkan id
      this.$http
        .delete(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          this.close();
          this.readData(); //mengambil data
          this.resetForm();
          this.inputType = "Tambah";
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    editHandler(item) {
      this.inputType = "Ubah";
      this.editId = item.id;
      this.form.id_customer = item.id_customer;
      this.form.id_meja = item.id_meja;
      this.form.sesi_reservasi = item.sesi_reservasi;
      this.form.status_reservasi = item.status_reservasi;
      this.form.tanggal_reservasi = item.tanggal_reservasi;
      this.form.tanggal_kunjung_reservasi = item.date;
      this.dialogEdit = true;
    },
    deleteHandler(id) {
      this.deleteId = id;
      this.dialogConfirm = true;
    },
    close() {
      this.dialog = false;
      this.dialogEdit = false;
      this.dialogConfirm = false;
      this.inputType = "Tambah";
    },
    cancel() {
      this.resetForm();
      this.readData();
      this.dialog = false;
      this.dialogCustomer = false;
      this.dialogEdit = false;
      this.inputType = "Tambah";
    },
    next() {
      this.readDataCustomer();
      this.dialogCustomer = false;
      this.dialog = true;
    },
    resetForm() {
      this.form = {
        id_customer: "",
        id_meja: "",
        sesi_reservasi: "",
        status_reservasi: "",
        tanggal_reservasi: "",
        date: "",
        nama_customer: "",
        email_customer: "",
        notelp_customer: "",
      };
    },
    showQR(item) {
      this.qr = item;
      this.qr.nama = item.nama_karyawan;
      this.id_pegawai = item.id_pegawai;
      this.value =
        // "Nomor Meja : " +
        // item.no_meja +
        // "\n" +
        // "Nama Customer : " +
        // item.nama_customer;
        "" + item.id;
      this.id_reservasi = item.id;
      this.id_customer = item.id_customer;
      this.dialogqr = true;
      this.hari_ini = moment
        .tz(moment(), "Asia/Jakarta")
        .format("MMM DD, YYYY h:mm:ss A");
    },
    cetak() {
      this.$refs.html2Pdf.generatePdf();
    },
  },
  computed: {
    formTitle() {
      return this.inputType;
    },
    costumers() {
      return ["ID", this.id];
    },
  },
  mounted() {
    this.readData();
    this.readDataCustomer();
    this.readDataMeja();
    this.readDataKaryawan();
    this.readDataMejaFull();
  },
};
</script>

<style scoped>
@import url("https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@400;600&display=swap");
.v-card--reveal {
  align-items: center;
  bottom: 0;
  justify-content: center;
  opacity: 5;
  position: absolute;
  width: 100%;
}

.myfont {
  font-family: "Roboto Slab", serif;
  color: white;
}

.fontpilih {
  font-family: "Roboto Slab", serif;
  font-size: 25px;
  color: white;
}

.font1 {
  font-family: "Fredoka One", cursive;
  font-size: 18px;
  color: white;
}

.font1Print {
  font-family: "Fredoka One", cursive;
  font-size: 18px;
  color: black;
}

.font2 {
  font-family: "Fredoka One", cursive;
  font-size: 15px;
  color: white;
}

.font2Print {
  font-family: "Fredoka One", cursive;
  font-size: 15px;
  color: rgb(53, 52, 52);
}

.fontqr {
  font-family: sans-serif;
  font-size: 25px;
  color: white;
}

.fontqrPrint {
  font-family: sans-serif;
  font-size: 25px;
  color: #d24848;
}

.fontBottom {
  font-family: serif;
  font-size: 25px;
  color: white;
}

.fontBottomPrint {
  font-family: serif;
  font-size: 25px;
  color: black;
}

.inputnumber input::-webkit-outer-spin-button,
.inputnumber input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
  display: none;
}
</style>
