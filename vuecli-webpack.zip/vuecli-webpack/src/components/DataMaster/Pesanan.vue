<template>
  <v-main class="list">
    <h3 class="text-h3 font-weight-medium mb-5 font-weight-bold white--text">
      Pesanan
    </h3>

    <v-card>
      <v-container v-if="id == 2">
        <v-tabs v-model="currentItem" fixed-tabs slider-color="white">
          <v-tab v-for="item in items" :key="item" :href="'#tab-' + item">
            {{ item }}
          </v-tab>
        </v-tabs>
      </v-container>
      <v-container v-if="id == 5">
        <v-tabs v-model="currentItem" fixed-tabs slider-color="white">
          <v-tab v-for="item in itemChefs" :key="item" :href="'#tab-' + item">
            {{ item }}
          </v-tab>
        </v-tabs>
      </v-container>
      <v-container v-if="id == 3 || id == 4">
        <v-tabs v-model="currentItem" fixed-tabs slider-color="white">
          <v-tab v-for="item in itemWaiters" :key="item" :href="'#tab-' + item">
            {{ item }}
          </v-tab>
        </v-tabs>
      </v-container>
      <v-tabs-items v-model="currentItem">
        <v-tab-item value="tab-Semua Pesanan">
          <v-card-title>
            <v-text-field
              v-model="search"
              clearable
              flat
              hide-details
              prepend-inner-icon="mdi-magnify"
              label="Search"
            ></v-text-field>
            <v-spacer></v-spacer>
          </v-card-title>
          <v-data-table :headers="headers" :items="pesanans" :search="search"
            ><template v-slot:[`item.status_pesanan`]="{ item }">
              <v-chip :color="getColor(item.status_pesanan)" dark>
                {{ item.status_pesanan }}
              </v-chip>
            </template>
            <template v-slot:[`item.actions`]="{ item }">
              <!-- <v-container v-if="id == 2 || id == 5"> -->
              <v-btn
                v-if="id == 2 || id == 5"
                icon
                color="yellow"
                @click="cookHandler(item)"
                :disabled="isServed(item.status_pesanan)"
              >
                <v-icon> mdi-check-bold </v-icon>
              </v-btn>
              <!-- </v-container> -->
              <v-btn
                v-if="id == 2 || id == 3 || id == 4"
                icon
                color="success"
                @click="serveHandler(item)"
                :disabled="isCook(item.status_pesanan)"
              >
                <v-icon> mdi-check-bold </v-icon>
              </v-btn>
            </template>
          </v-data-table>
        </v-tab-item>
        <v-tab-item value="tab-Pesanan Dimasak">
          <v-card-title>
            <v-text-field
              v-model="search"
              clearable
              flat
              hide-details
              prepend-inner-icon="mdi-magnify"
              label="Search"
            ></v-text-field>
            <v-spacer></v-spacer>
          </v-card-title>
          <v-data-table
            :headers="headers"
            :items="pesananCooks"
            :search="search"
            ><template v-slot:[`item.status_pesanan`]="{ item }">
              <v-chip :color="getColor(item.status_pesanan)" dark>
                {{ item.status_pesanan }}
              </v-chip>
            </template>
            <template v-slot:[`item.actions`]="{ item }">
              <v-btn icon color="yellow" @click="cookHandler(item)">
                <v-icon> mdi-check-bold </v-icon>
              </v-btn>
            </template>
          </v-data-table>
        </v-tab-item>
        <v-tab-item value="tab-Pesanan Siap Disajikan">
          <v-card-title>
            <v-text-field
              v-model="search"
              clearable
              flat
              hide-details
              prepend-inner-icon="mdi-magnify"
              label="Search"
            ></v-text-field>
            <v-spacer></v-spacer>
          </v-card-title>
          <v-data-table
            :headers="headers"
            :items="pesananReadys"
            :search="search"
            ><template v-slot:[`item.status_pesanan`]="{ item }">
              <v-chip :color="getColor(item.status_pesanan)" dark>
                {{ item.status_pesanan }}
              </v-chip>
            </template>
            <template v-slot:[`item.actions`]="{ item }">
              <v-btn icon color="success" @click="serveHandler(item)">
                <v-icon> mdi-check-bold </v-icon>
              </v-btn>
            </template>
          </v-data-table>
        </v-tab-item>
      </v-tabs-items>
    </v-card>

    <v-snackbar v-model="snackbar" :color="color" timeout="2000" bottom>
      {{ error_message }}
    </v-snackbar>
  </v-main>
</template>
<script>
export default {
  name: "List",
  data() {
    return {
      inputType: "Tambah",
      load: false,
      snackbar: false,
      error_message: "",
      color: "",
      search: null,
      dialog: false,
      dialogEdit: false,
      dialogConfirm: false,
      headers: [
        {
          text: "Nomor Meja",
          align: "start",
          sortable: true,
          value: "no_meja",
        },
        { text: "Menu", value: "nama_menu" },
        { text: "Jumlah Item", value: "jumlah_item" },
        { text: "Status Pesanan", value: "status_pesanan" },
        { text: "Actions", value: "actions" },
      ],
      //   karyawan: new FormData(),
      pesanans: [],
      pesananCooks: [],
      pesananReadys: [],
      form: {
        name: "",
        id_role: null,
        email: "",
        jenis_kelamin_karyawan: null,
        notelp_karyawan: "",
        tanggal_gabung_karyawan: "",
      },
      roles: [],
      editId: "",
      id_bahan: "",
      id: "",
      tampilCook: true,
      items: ["Semua Pesanan", "Pesanan Dimasak", "Pesanan Siap Disajikan"],
      itemChefs: ["Semua Pesanan", "Pesanan Dimasak"],
      itemWaiters: ["Semua Pesanan", "Pesanan Siap Disajikan"],
      currentItem: "tab-Semua Pesanan",
    };
  },
  methods: {
    setForm() {
      if (this.inputType === "Tambah") {
        this.save();
      } else {
        this.update();
      }
    },
    //read data pesanan
    readData() {
      var url = this.$api + "/detailPembayaran";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.pesanans = response.data.data;
        });
    },
    //read data pesanan cook
    readDataCook() {
      var url = this.$api + "/detailPembayaranCook";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.pesananCooks = response.data.data;
        });
    },
    //read data pesanan ready
    readDataReady() {
      var url = this.$api + "/detailPembayaranReady";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.pesananReadys = response.data.data;
        });
    },
    //ubah data produk
    update() {
      let newData = {
        status_pesanan: "Served",
      };
      var url = this.$api + "/detailPembayaranServed/" + this.editId;
      this.load = true;
      this.$http
        .put(url, newData, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          //   this.close();
          this.readData(); //mengambil data
          this.readDataCook();
          //   this.resetForm();
          this.inputType = "Tambah";
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    updateCook() {
      let newData = {
        status_pesanan: "Ready",
      };
      var url = this.$api + "/detailPembayaranServed/" + this.editId;
      this.load = true;
      this.$http
        .put(url, newData, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          //   this.close();
          this.readData(); //mengambil data
          this.readDataCook();
          //   this.resetForm();
          this.inputType = "Tambah";
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    cookHandler(item) {
      this.inputType = "Ubah";
      this.editId = item.id;
      this.updateCook();
    },
    serveHandler(item) {
      this.inputType = "Ubah";
      this.editId = item.id;
      this.update();
    },
    close() {
      this.dialog = false;
      this.dialogEdit = false;
      this.dialogConfirm = false;
      this.inputType = "Tambah";
    },
    cancel() {
      this.resetForm();
      this.readData();
      this.dialog = false;
      this.dialogEdit = false;
      this.inputType = "Tambah";
    },
    resetForm() {
      this.form = {
        name: "",
        id_role: "",
        email: "",
        password: "",
        jenis_kelamin_karyawan: "",
        notelp_karyawan: "",
        tanggal_gabung_karyawan: "",
      };
    },
    getColor(status_pesanan) {
      if (status_pesanan == "Cook") return "red";
      else if (status_pesanan == "Ready") return "yellow darken-2";
      else return "green";
    },
    isServed(status_pesanan) {
      if (status_pesanan == "Served" || status_pesanan == "Ready") return true;
      else return false;
    },
    isCook(status_pesanan) {
      if (status_pesanan == "Served" || status_pesanan == "Cook") return true;
      else return false;
    },
  },
  computed: {
    formTitle() {
      return this.inputType;
    },
  },
  mounted() {
    this.readData();
    this.readDataCook();
    this.readDataReady();
    this.id = localStorage.getItem("id");
  },
};
</script>
