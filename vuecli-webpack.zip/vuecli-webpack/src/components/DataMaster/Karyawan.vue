<template>
  <v-main class="list">
    <h3 class="text-h3 font-weight-medium mb-5 font-weight-bold white--text">
      Karyawan
    </h3>

    <v-card>
      <v-card-title>
        <v-text-field
          v-model="search"
          append-icon="mdi-magnify"
          label="Search"
          single-line
          hide-details
        ></v-text-field>

        <v-spacer></v-spacer>
        <v-tooltip bottom>
          <template v-slot:activator="{ on, attrs }">
            <v-btn
              icon
              color="success"
              dark
              @click="dialog = true"
              v-bind="attrs"
              v-on="on"
            >
              <v-icon> mdi-plus </v-icon>
            </v-btn>
          </template>
          <span> Tambah </span>
        </v-tooltip>
      </v-card-title>

      <v-data-table :headers="headers" :items="karyawans" :search="search">
        <template v-slot:[`item.actions`]="{ item }">
          <v-btn
            icon
            color="blue"
            @click="editHandler(item)"
            :disabled="isDeleted(item.deleted_at)"
          >
            <v-icon> mdi-pencil </v-icon>
          </v-btn>

          <v-btn
            icon
            color="red"
            @click="deleteHandler(item.id)"
            :disabled="isDeleted(item.deleted_at)"
          >
            <v-icon> mdi-delete </v-icon>
          </v-btn>
        </template>
      </v-data-table>
    </v-card>

    <v-dialog v-model="dialog" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <span class="headline">{{ formTitle }} Karyawan</span>
        </v-card-title>

        <v-card-text>
          <v-form v-model="valid" ref="form">
            <v-text-field
              v-model="form.name"
              label="Nama Karyawan"
              required
              :rules="namaRules"
            ></v-text-field>

            <v-select
              v-model="form.id_role"
              :items="roles"
              item-text="nama_role"
              item-value="id"
              label="Role"
              required
              :rules="roleRules"
            ></v-select>

            <v-text-field
              v-model="form.email"
              label="Email"
              required
              :rules="emailRules"
            ></v-text-field>

            <v-text-field
              v-model="form.password"
              label="Password"
              type="password"
              required
              :rules="passwordRules"
            ></v-text-field>

            <v-select
              v-model="form.jenis_kelamin_karyawan"
              :items="['Laki-laki', 'Perempuan']"
              label="Jenis Kelamin"
              required
              :rules="jkRules"
            ></v-select>

            <v-text-field
              v-model="form.notelp_karyawan"
              label="Nomor Telepon"
              required
              :rules="notelpRules"
            ></v-text-field>

            <v-menu
              v-model="menu"
              :close-on-content-click="false"
              :nudge-right="40"
              transition="scale-transition"
              offset-y
              min-width="auto"
            >
              <template v-slot:activator="{ on, attrs }">
                <v-text-field
                  v-model="date"
                  label="Tanggal Gabung"
                  prepend-icon="mdi-calendar"
                  readonly
                  v-bind="attrs"
                  v-on="on"
                  :rules="tglGabungRules"
                ></v-text-field>
              </template>
              <v-date-picker
                v-model="date"
                @input="menu = false"
              ></v-date-picker>
            </v-menu>
          </v-form>
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn color="blue darken-1" text @click="cancel">
            Cancel
          </v-btn>

          <v-btn color="blue darken-1" text @click="setForm">
            Save
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogEdit" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <span class="headline">{{ formTitle }} Karyawan</span>
        </v-card-title>

        <v-card-text>
          <v-form v-model="valid" ref="form">
            <v-text-field
              v-model="form.name"
              label="Nama"
              required
            ></v-text-field>

            <v-select
              v-model="form.id_role"
              :items="roles"
              item-text="nama_role"
              item-value="id"
              label="Role"
              required
            ></v-select>

            <v-select
              v-model="form.jenis_kelamin_karyawan"
              :items="['Laki-laki', 'Perempuan']"
              label="Jenis Kelamin"
              required
            ></v-select>

            <v-text-field
              v-model="form.notelp_karyawan"
              label="Nomor Telepon"
              required
            ></v-text-field>

            <v-text-field
              v-model="form.email"
              label="Email Telepon"
              required
            ></v-text-field>

            <v-menu
              v-model="menu2"
              :close-on-content-click="false"
              :nudge-right="40"
              transition="scale-transition"
              offset-y
              min-width="auto"
            >
              <template v-slot:activator="{ on, attrs }">
                <v-text-field
                  v-model="date"
                  label="Tanggal Gabung"
                  prepend-icon="mdi-calendar"
                  readonly
                  v-bind="attrs"
                  v-on="on"
                ></v-text-field>
              </template>
              <v-date-picker
                v-model="date"
                @input="menu2 = false"
              ></v-date-picker>
            </v-menu>
          </v-form>
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn color="blue darken-1" text @click="cancel">
            Cancel
          </v-btn>

          <v-btn color="blue darken-1" text @click="update">
            Save
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogConfirm" persistent max-width="400px">
      <v-card>
        <v-card-title>
          <span class="headline">Warning!</span>
        </v-card-title>

        <v-card-text>
          Anda yakin ingin menghapus Karyawan ini?
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn color="blue darken-1" text @click="dialogConfirm = false">
            Cancel
          </v-btn>

          <v-btn color="blue darken-1" text @click="deleteData">
            Delete
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-snackbar v-model="snackbar" :color="color" timeout="2000" bottom>
      {{ error_message }}
    </v-snackbar>
  </v-main>
</template>
<script>
export default {
  name: "List",
  data() {
    return {
      inputType: "Tambah",
      load: false,
      snackbar: false,
      error_message: "",
      color: "",
      search: null,
      dialog: false,
      dialogEdit: false,
      dialogConfirm: false,
      headers: [
        { text: "Nama", align: "start", sortable: true, value: "name" },
        { text: "Role", value: "nama_role" },
        { text: "Email", value: "email" },
        { text: "Jenis Kelamin", value: "jenis_kelamin_karyawan" },
        { text: "Nomor Telepon", value: "notelp_karyawan" },
        { text: "Tanggal Gabung", value: "tanggal_gabung_karyawan" },
        { text: "Actions", value: "actions" },
      ],
      karyawan: new FormData(),
      karyawans: [],
      form: {
        name: "",
        id_role: null,
        email: "",
        jenis_kelamin_karyawan: null,
        notelp_karyawan: "",
        tanggal_gabung_karyawan: "",
      },
      roles: [],
      deleteId: "",
      editId: "",
      date: new Date().toISOString().substr(0, 10),
      menu: false,
      menu2: false,
      namaRules: [(v) => !!v || "Nama Karyawan tidak boleh kosong"],
      roleRules: [(v) => !!v || "Role tidak boleh kosong"],
      emailRules: [(v) => !!v || "Email tidak boleh kosong"],
      passwordRules: [(v) => !!v || "Password tidak boleh kosong"],
      jkRules: [(v) => !!v || "Jenis Kelamin tidak boleh kosong"],
      notelpRules: [(v) => !!v || "Nomor Telepon tidak boleh kosong"],
      tglGabungRules: [(v) => !!v || "Tanggal Gabung tidak boleh kosong"],
    };
  },
  methods: {
    setForm() {
      if (this.inputType === "Tambah") {
        this.save();
      } else {
        this.update();
      }
    },
    //read data karyawan
    readData() {
      var url = this.$api + "/karyawan";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.karyawans = response.data.data;
        });
    },
    // read data role
    readDataRole() {
      var url = this.$api + "/role";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.roles = response.data.data;
        });
    },
    //simpan data produk
    save() {
      if (this.$refs.form.validate()) {
        this.karyawan.append("name", this.form.name);
        this.karyawan.append("id_role", this.form.id_role);
        this.karyawan.append("email", this.form.email);
        this.karyawan.append("password", this.form.password);
        this.karyawan.append(
          "jenis_kelamin_karyawan",
          this.form.jenis_kelamin_karyawan
        );
        this.karyawan.append("notelp_karyawan", this.form.notelp_karyawan);
        this.karyawan.append("tanggal_gabung_karyawan", this.date);

        var url = this.$api + "/karyawan/";
        this.load = true;
        this.$http
          .post(url, this.karyawan, {
            headers: {
              Authorization: "Bearer " + localStorage.getItem("token"),
            },
          })
          .then((response) => {
            this.error_message = response.data.message;
            this.color = "green";
            this.snackbar = true;
            this.load = false;
            this.close();
            this.readData(); //mengambil data
            this.resetForm();
          })
          .catch((error) => {
            this.error_message = error.response.data.message;
            this.color = "red";
            this.snackbar = true;
            this.load = false;
          });
      }
    },
    //ubah data produk
    update() {
      let newData = {
        name: this.form.name,
        id_role: this.form.id_role,
        email: this.form.email,
        jenis_kelamin_karyawan: this.form.jenis_kelamin_karyawan,
        notelp_karyawan: this.form.notelp_karyawan,
        tanggal_gabung_karyawan: this.date,
      };
      var url = this.$api + "/karyawan/" + this.editId;
      this.load = true;
      this.$http
        .put(url, newData, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          this.close();
          this.readData(); //mengambil data
          this.resetForm();
          this.inputType = "Tambah";
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    //hapus data produk
    deleteData() {
      //mengahapus data
      var url = this.$api + "/karyawan/" + this.deleteId;
      //data dihapus berdasarkan id
      this.$http
        .delete(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          this.close();
          this.readData(); //mengambil data
          this.resetForm();
          this.inputType = "Tambah";
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    editHandler(item) {
      this.inputType = "Ubah";
      this.editId = item.id;
      this.form.name = item.name;
      this.form.id_role = item.id_role;
      this.form.email = item.email;
      this.form.jenis_kelamin_karyawan = item.jenis_kelamin_karyawan;
      this.form.notelp_karyawan = item.notelp_karyawan;
      this.form.tanggal_gabung_karyawan = item.tanggal_gabung_karyawan;
      this.dialogEdit = true;
    },
    deleteHandler(id) {
      this.deleteId = id;
      this.dialogConfirm = true;
    },
    close() {
      this.dialog = false;
      this.dialogEdit = false;
      this.dialogConfirm = false;
      this.inputType = "Tambah";
    },
    cancel() {
      this.resetForm();
      this.readData();
      this.dialog = false;
      this.dialogEdit = false;
      this.inputType = "Tambah";
    },
    resetForm() {
      this.form = {
        name: "",
        id_role: "",
        email: "",
        password: "",
        jenis_kelamin_karyawan: "",
        notelp_karyawan: "",
        tanggal_gabung_karyawan: "",
      };
    },
    isDeleted(deleted_at) {
      if (deleted_at == null) return false;
      else return true;
    },
  },
  computed: {
    formTitle() {
      return this.inputType;
    },
  },
  mounted() {
    this.readData();
    this.readDataRole();
  },
};
</script>
